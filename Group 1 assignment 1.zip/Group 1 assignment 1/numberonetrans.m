%Reading the workbook into Matlab
T = readtable("A:\desktop\assignment 1 ammended\climate_change_dataset.xlsx"...
    ,Range="A1:T54",ReadVariableNames=true);

%Extracting data of different years from the table into separate tables.
A2020 = T(1:12,:);
B2021 = T(13:24,:);
C2022 = T(25:36,:);
D2023 = T(37:48,:);
E2024 = T(49:53,:);

%Converting the tables into structural arrays.
S2020 = table2struct(A2020);
S2021 = table2struct(B2021);
S2022 = table2struct(C2022);
S2023 = table2struct(D2023);
S2024 = table2struct(E2024);

%Converting the structural arrays into tables.
T2020 = struct2table(S2020);
T2021 = struct2table(S2021);
T2022 = struct2table(S2022);
T2023 = struct2table(S2023);
T2024 = struct2table(S2024);

%Assigning a variable to the excel workbook file path.
excelOutput = "A:\desktop\assignment 1 ammended\Export workbook.xlsx";

%writing each table into a separate sheet of the same workbook.
writetable(T2020,excelOutput,'Sheet','T2020');
writetable(T2021,excelOutput,'Sheet','T2021');
writetable(T2022,excelOutput,'Sheet','T2022');
writetable(T2023,excelOutput,'Sheet','T2023');
writetable(T2024,excelOutput,'Sheet','T2024');
disp('Processing complete. Files saved in Assignment 1 ammended folder.');