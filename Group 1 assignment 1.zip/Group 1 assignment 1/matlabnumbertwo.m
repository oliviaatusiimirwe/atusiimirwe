%% Defining struct
Members= struct('Name',{},'Age',{},'Course',{},'HomeDistrict',{},'Tribe',{},'Facialrepresentation',{},'Interests',{});
%Member1
Members(1).Name='Ikeo Jesca';
Members(1).Age=22;
Members(1).Course='WAR';
Members(1).HomeDistrict='Kaberamaido';
Members(1).Tribe='Kumam';
Members(1).Facialrepresentation=imread('ngc6543a.jpg');
Members(1).Interests='Alot';
%Member 2
Members(2).Name='Mugisha Peter';
Members(2).Age=23;
Members(2).Course='AMI';
Members(2).HomeDistrict='Koboko';
Members(2).Tribe='Itesot';
Members(2).Facialrepresentation=imread('ngc6543a.jpg');
Members(2).Interests='Football';
%Member 3
Members(3).Name = 'Atusiimirwe Olivia';
Members(3).Age = 22;
Members(3).Course = 'WAR';
Members(3).HomeDistrict = 'Kiruhura';
Members(3).Tribe = 'Munyankore';
Members(3).Interests = 'Food';
Members(3).Facialrepresentation=imread('ngc6543a.jpg');
%Member 4
Members(4).Name = 'Ssentude Ibrahim';
Members(4).Age = 23;
Members(4).Course = 'WAR';
Members(4).HomeDistrict = 'MASAKA';
Members(4).Tribe = 'Muganda';
Members(4).Interests = 'Football';
Members(4).Facialrepresentation = imread('ngc6543a.jpg');
%Member 5
 Members(5).Name = 'Mutaryebwa Luke';
Members(5).Age = 22;
Members(5).Course = 'WAR';
Members(5).HomeDistrict = 'BUSHENYI';
Members(5).Tribe = 'Munyankore';
Members(5).Interests = 'Politics';
Members(5).Facialrepresentation = imread('ngc6543a.jpg');
%Member 6
Members(6).Name = 'Makaayi Hakim';
Members(6).Age = 21;
Members(6).Course = 'PTI';
Members(6).HomeDistrict = 'WAKISO';
Members(6).Tribe = 'Muganda';
Members(6).Interests = 'Coding';
Members(6).Facialrepresentation = imread('ngc6543a.jpg');
%Member 7
Members(7).Name = 'Chelimo Sandra';
Members(7).Age = 22;
Members(7).Course = 'WAR';
Members(7).HomeDistrict = 'Kapchorwa';
Members(7).Tribe = 'Itesot';
Members(7).Interests = 'Dancing';
Members(7).Facialrepresentation = imread('ngc6543a.jpg');
%Member 8
Members(8).Name = 'Nakabugo Haula';
Members(8).Age = 21;
Members(8).Course = 'AMI';
Members(8).HomeDistrict = 'WAKISO';
Members(8).Tribe = 'Muganda';
Members(8).Interests = 'Modelling';
Members(8).Facialrepresentation = imread('ngc6543a.jpg');
%Member 9
Members(9).Name = 'Nakazibwe Ethel';
Members(9).Age = 22;
Members(9).Course = 'AMI';
Members(9).HomeDistrict = 'KAMPALA';
Members(9).Tribe = 'Muganda';
Members(9).Interests = 'Basketball';
Members(9).Facialrepresentation = imread('ngc6543a.jpg');
%Member 10
Members(10).Name = 'Atim Gloria';
Members(10).Age = 22;
Members(10).Course = 'WAR';
Members(10).HomeDistrict = 'MUKONO';
Members(10).HomeDistrict = 'SOROTI';
Members(10).Tribe = 'Itesot';
Members(10).Interests = 'Graphics';
Members(10).Facialrepresentation = imread('ngc6543a.jpg');
%Member 11
Members(11).Name = 'Adongo Poffia';
Members(11).Age = 23;
Members(11).Course = 'AMI';
Members(11).HomeDistrict = 'ARUA';
Members(11).Tribe = 'Arur';
Members(11).Interests = 'Music';
Members(11).Facialrepresentation = imread('ngc6543a.jpg');
%Member 12
Members(12).Name = 'Mutaka Amos';
Members(12).Age = 20;
Members(12).Course = 'WAR';
Members(12).HomeDistrict = 'MBALE';
Members(12).Tribe = 'Samia';
Members(12).Interests = 'Football';
Members(12).Facialrepresentation = imread('ngc6543a.jpg');
%Member 13
Members(13).Name = 'Wafula Daniel';
Members(13).Age = 22;
Members(13).Course = 'WAR';
Members(13).HomeDistrict = 'APAC';
Members(13).Tribe = 'Itesot';
Members(13).Interests = 'Music';
Members(13).Facialrepresentation = imread('ngc6543a.jpg');
%Members 14
Members(14).Name = 'Owor Hamidu';
Members(14).Age = 21;
Members(14).Course = 'PTI';
Members(14).HomeDistrict = 'LIRA';
Members(14).Tribe = 'Kumam';
Members(14).Interests = 'Dancing';
Members(14).Facialrepresentation = imread('ngc6543a.jpg');
%Member 15
Members(15).Name = 'Wamabasa Geofrey';
Members(15).Age = 22;
Members(15).Course = 'WAR';
Members(15).HomeDistrict = 'NAKASEKE';
Members(15).Tribe = 'Musoga';
Members(15).Interests = 'Football';
Members(15).Facialrepresentation = imread('ngc6543a.jpg');
%Member 16
Members(16).Name = 'Muhangi Mathew';
Members(16).Age = 23;
Members(16).Course = 'MEB';
Members(16).HomeDistrict = 'MBARARA';
Members(16).Tribe = 'Munyankore';
Members(16).Interests = 'Politics';
Members(16).Facialrepresentation = imread('ngc6543a.jpg');
%Members
Members(17).Name = 'Obur Charles';
Members(17).Age = 22;
Members(17).Course = 'PTI';
Members(17).HomeDistrict = 'ARUA';
Members(17).Tribe = 'Lugbara';
Members(17).Interests = 'Movies';
Members(17).Facialrepresentation = imread('ngc6543a.jpg');
%Members 18
Members(18).Name = 'Okot Sandra';
Members(18).Age = 21;
Members(18).Course = 'WAR';
Members(18).Name = 'Okot';
Members(18).HomeDistrict = 'Dokolo';
Members(18).Tribe = 'Langi';
Members(18).Interests = 'Football';
Members(18).Facialrepresentation = imread('ngc6543a.jpg');
%Member 19
Members(19).Name = 'Omali Emmanuel';
Members(19).Age = 22;
Members(19).Course = 'WAR';
Members(19).HomeDistrict = 'AMURAT';
Members(19).Tribe = 'Itesot';
Members(19).Interests = 'Music';
Members(19).Facialrepresentation = imread('ngc6543a.jpg');
%Member 20
Members(20).Name = 'Ochen Paul';
Members(20).Age = 22;
Members(20).Course = 'AMI';
Members(20).HomeDistrict = 'Gulu';
Members(20).Tribe = 'Acholi';
Members(20).Interests = 'Football';
Members(20).Facialrepresentation = imread('ngc6543a.jpg');
