%Reading the workbook into Matlab
T = readtable("A:\desktop\assignment 1 ammended\climate_change_dataset.xlsx"...
    ,Range="A1:T54",ReadVariableNames=true);

%Extracting data of different years from the table into separate tables.
A2020 = T(1:12,:);
B2021 = T(13:24,:);
C2022 = T(25:36,:);
D2023 = T(37:48,:);
E2024 = T(49:53,:);

%Converting the tables into structural arrays.
S2020 = table2struct(A2020);
S2021 = table2struct(B2021);
S2022 = table2struct(C2022);
S2023 = table2struct(D2023);
S2024 = table2struct(E2024);

%Converting the structural arrays into tables.
T2020 = struct2table(S2020);
T2021 = struct2table(S2021);
T2022 = struct2table(S2022);
T2023 = struct2table(S2023);
T2024 = struct2table(S2024);

%Assigning a variable to the excel workbook file path.
excelOutput = "A:\desktop\assignment 1 ammended\Export workbook.xlsx";

%writing each table into a separate sheet of the same workbook.
writetable(T2020,excelOutput,'Sheet','T2020');
writetable(T2021,excelOutput,'Sheet','T2021');
writetable(T2022,excelOutput,'Sheet','T2022');
writetable(T2023,excelOutput,'Sheet','T2023');
writetable(T2024,excelOutput,'Sheet','T2024');
disp('Processing complete. Files saved in MatlabExcel Assignment folder.');

%%2D PLOTS
%1.Lineplots,Scatterplot,Bar graph.
figure("Name", "Lineplots, Scatterplot and Bar graph");
%Subplot 1;lineplots showing Average Temperature for years 2020 to 2024
subplot(2,2,1)
plot(A2020.Month,A2020.Avg_Temp___C_,"b-*");
hold on;
plot(B2021.Month,B2021.Avg_Temp___C_,"k--s");
plot(C2022.Month,C2022.Avg_Temp___C_,"g-o");
plot(D2023.Month,D2023.Avg_Temp___C_,"c--s");
plot(E2024.Month,E2024.Avg_Temp___C_,"r:o");
legend("A2020","B2021","C2022" ,"D2023","E2024");
hold off;
xlabel('Months');
ylabel('Avg.Temp(C)');
title('Average Temperature per month for the years 2020 to 2024');
grid on;

%Subplot 2;Scatterplots showing Humidity for years 2020 to 2024
subplot(2,2,2)
scatter(A2020.Month,A2020.Humidity___,"b*");
hold on;
scatter(B2021.Month,B2021.Humidity___,"ks");
scatter(C2022.Month,C2022.Humidity___,"go");
scatter(D2023.Month,D2023.Humidity___,"cs");
scatter(E2024.Month,E2024.Humidity___,"ro");
legend("A2020","B2021","C2022","D2023","E2024");
hold off;
xlabel('Months');
ylabel('Humidity');
title('Humidity per month for the years 2020 to 2024');
grid on;

%Subplot 3;Bar graph showing the Solar Irradiance across the 12 months of 2020
subplot(2,2,3)
xaxis = categorical(A2020.Month);
yaxis = (A2020.Solar_Irradiance_W_m___);
bar(xaxis,yaxis);
xlabel('Months');
ylabel('Solar Irradiance');
title('Bar graph showing Solar Irradiance in the year 2020 for the twelve months');
grid on;

%Subplot 4; Line plot showing Precipitation and Humidity
subplot(2,2,4);
dates = datetime(T.Year, T.Month, 1); % Assume 1st of each month
yyaxis left;
plot(dates,T.Precipitation_mm_, 'b', 'LineWidth', 1.5);
ylabel('Precipitation (mm)');
yyaxis right;
plot(dates,T.Humidity___, 'blue', 'LineWidth', 1.5);
ylabel('Humidity (%)');
title('Precipitation vs Humidity');
legend('Precipitation', 'Humidity', 'Location', 'best');
grid on;

figure("Name","Box plot,Histogram,StemPlot,StepPlot");
%subplot 1; Box plot showing average temperature from 2020 to 2024.
subplot(2,2,1);
boxdata = A2020.Avg_Temp___C_;B2021.Avg_Temp___C_,C2022.Avg_Temp___C_,...
    D2023.Avg_Temp___C_,E2024.Avg_Temp___C_;
boxplot(boxdata);
grid on;
title("Box plot showing Average Temperature from 2020 to 2024");

%subplot 2; Histogram showing Distribution of Average Temperature.
subplot(2,2,2);
histogram(T.Avg_Temp___C_, 15, 'FaceColor', 'cyan', 'EdgeColor', 'b');
title('Distribution of Average Temperature');
xlabel('Temperature (°C)');
ylabel('Frequency');

%subplot 3; Stem Plot: Monthly Max Temperatures for 2023
subplot(2,2,3);
stem(D2023.Month, D2023.Max_Temp___C_, 'filled', 'LineWidth', 1.5);
title('Monthly Max Temperature of 2023');
xlabel('Month');
ylabel('Max Temp (°C)');
grid on;

%subplot 4; CO₂ Concentration over time for 2022
subplot(2,2,4);
stairs(C2022.Month, C2022.CO2_Concentration_ppm_, 'r-', 'LineWidth', 1.3);
title('CO₂ Concentration for 2022');
xlabel('Month');
ylabel('CO₂ (ppm)');
grid on;

figure("Name","PieChart,Error Bar")
%subplot 1; A piechart showing the Cloud cover in 5 months of 2024
subplot(1,2,1);
pie(E2024.Cloud_Cover___,E2024.Month);
title("Cloudcover data for 2024")
legend("Jan","Feb","March","April","May")
box on

%subplot 2; Error Bar Plot showing Monthly Urbanization and Vegetation Index
subplot(1,2,2);
errorbar(A2020.Month, A2020.Urbanization_Index, A2020.Vegetation_Index,...
    'o', 'LineWidth', 1.5, 'CapSize', 10);
title('Urbanization, Vegetation Index');
xlabel('Month');
ylabel('Index');
grid on;

%%3D PLOTS
figure("Name","3D scatter plot,3D stem plot,3D mesh plot,Bubble chart")
%subplot 1; 3D Scatter Plot
subplot(2,2,1);
scatter3(T.CO2_Concentration_ppm_, T.Humidity___, T.Avg_Temp___C_, 40,...
    T.Month, 'filled');
colorbar;
xlabel('CO₂ (ppm)');
ylabel('Humidity (%)');
zlabel('Avg Temp (°C)');
title('Temp vs CO₂ vs Humidity (Colored by Month)');
grid on;

%subplot 2; 3D Stem Plot for 2022 comparing temperatures.
subplot(2,2,2);
stem3(C2022.Month, C2022.Max_Temp___C_, C2022.Min_Temp___C_, 'filled',...
    'LineWidth', 1.5);
xlabel('Month');
ylabel('Max Temp (°C)');
zlabel('Min Temp (°C)');
title('2022 Min/Max Temp by Month');
grid on;

%subplot 3; Mesh plot of Temperature Data for 2023
subplot(2,2,3);
% Create meshgrid using month numbers.
[Lm,Em] = meshgrid(1:12);
% Calculate monthly averages directly.
kv = repmat(grpstats(D2023, 'Month', 'mean', 'DataVars', 'Avg_Temp___C_')...
    .mean_Avg_Temp___C_', size(Lm, 1), 1);

mesh(Lm, Em, kv);
colorbar;
xlabel('Month');
ylabel('Y');
zlabel('Average Temperature (°C)');
grid on;
title('Mesh Plot showing Temperature data of 2023');

%subplot 4; Bubble chart showing temperature versus time 
subplot(2,2,4);
bubblechart3(T.Year, T.Month, T.Avg_Temp___C_, T.Precipitation_mm_/10, T.Humidity___);
xlabel('Year');
ylabel('Month');
zlabel('Avg Temp (°C)');
title('Bubble Chart: Temp vs Time (Size: Precip, Color: Humidity)');
bubblesize([5 20]);
colorbar;
grid on;

figure("Name","Waterfall,Ribbon plot")
%subplot 1; Waterfall plot of Cloud Cover for 2023
subplot(1,2,1);
% Create meshgrid using month numbers.
[Em,Xm] = meshgrid(1:12);
% Calculate monthly averages directly.
Rv = repmat(grpstats(D2023, 'Month', 'mean', 'DataVars', 'Cloud_Cover___')...
    .mean_Cloud_Cover___', size(Em, 1), 1);

waterfall(Lm, Em, Rv);
colorbar;
xlabel('Month');
ylabel('Y');
zlabel('Average Temperature (°C)');
grid on;
title('Waterfall Plot showing Temperature data of 2023');

%subplot 2; Ribbon plot showing the maximum and minimum temperature in 2020
subplot(1,2,2);
YR = A2020.Max_Temp___C_;
ZR = A2020.Min_Temp___C_;
ylabel("Max Temp")
zlabel("Min Temp")
title("Ribbon plot relating maximum and minimum temperature in 2020")
ribbon(YR,ZR)
