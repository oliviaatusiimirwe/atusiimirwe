%% Defining struct
Members= struct('Name',{},'Age',{},'Course',{},'HomeDistrict',{},'Tribe',{},'Facialrepresentation',{},'Interests',{});
%Member1
Members(1).Name='Ikeo Jesca';
Members(1).Age=22;
Members(1).Course='WAR';
Members(1).HomeDistrict='Kaberamaido';
Members(1).Tribe='Kumam';
Members(1).Facialrepresentation=imread('C:\Users\USER\Desktop\GROUP 1\jesca.jpg');
Members(1).Interests='Alot';
%Member 2
Members(2).Name='Mugisha Peter';
Members(2).Age=23;
Members(2).Course='AMI';
Members(2).HomeDistrict='Ntungamo';
Members(2).Tribe='Itesot';
Members(2).Facialrepresentation=imread('C:\Users\USER\Desktop\GROUP 1\peter.jpg');
Members(2).Interests='Football';
%Member 3
Members(3).Name = 'Atusiimirwe Olivia';
Members(3).Age = 22;
Members(3).Course = 'WAR';
Members(3).HomeDistrict = 'Kiruhura';
Members(3).Tribe = 'Munyankore';
Members(3).Interests = 'Food';
Members(3).Facialrepresentation=imread('C:\Users\USER\Desktop\GROUP 1\olive.jpg');
%Member 4
Members(4).Name = 'Ssentude Ibrahim';
Members(4).Age = 23;
Members(4).Course = 'WAR';
Members(4).HomeDistrict = 'MASAKA';
Members(4).Tribe = 'Muganda';
Members(4).Interests = 'Football';
Members(4).Facialrepresentation = imread('C:\Users\USER\Desktop\GROUP 1\rahim.jpg');
%Member 5
 Members(5).Name = 'Mutaryebwa Luke';
Members(5).Age = 22;
Members(5).Course = 'WAR';
Members(5).HomeDistrict = 'BUSHENYI';
Members(5).Tribe = 'Munyankore';
Members(5).Interests = 'Politics';
Members(5).Facialrepresentation = imread('C:\Users\USER\Desktop\GROUP 1\luke.jpg');
%Member 6
Members(6).Name = 'Makaayi Hakim';
Members(6).Age = 21;
Members(6).Course = 'PTI';
Members(6).HomeDistrict = 'WAKISO';
Members(6).Tribe = 'Muganda';
Members(6).Interests = 'Coding';
Members(6).Facialrepresentation = imread('ngc6543a.jpg');
%Member 7
Members(7).Name = 'Lucky Dororthy';
Members(7).Age = 21;
Members(7).Course = 'MEB';
Members(7).HomeDistrict = 'Ntungamo';
Members(7).Tribe = 'Munyankole';
Members(7).Interests = 'Eating';
Members(7).Facialrepresentation = imread('C:\Users\USER\Desktop\GROUP 1\dorothy.jpg');
%Member 8
Members(8).Name = 'Nakabugo Haula';
Members(8).Age = 21;
Members(8).Course = 'AMI';
Members(8).HomeDistrict = 'WAKISO';
Members(8).Tribe = 'Muganda';
Members(8).Interests = 'Modelling';
Members(8).Facialrepresentation = imread('C:\Users\USER\Desktop\GROUP 1\haula.jpg');
%Member 9
Members(9).Name = 'Atim Gloria';
Members(9).Age = 22;
Members(9).Course = 'WAR';
Members(9).HomeDistrict = 'MUKONO';
Members(9).HomeDistrict = 'SOROTI';
Members(9).Tribe = 'Itesot';
Members(9).Interests = 'Graphics';
Members(9).Facialrepresentation = imread('C:\Users\USER\Desktop\GROUP 1\gloria.jpg');
%Member 10
Members(10).Name = 'Mutaka Amos';
Members(10).Age = 20;
Members(10).Course = 'WAR';
Members(10).HomeDistrict = 'MBALE';
Members(10).Tribe = 'Musoga';
Members(10).Interests = 'Football';
Members(10).Facialrepresentation = imread('C:\Users\USER\Desktop\GROUP 1\amos.jpg');
%Bar graph of Ages against Names
x = categorical({'Ikeo Jesca','Mugisha Peter','Atusiimirwe Olivia','Ssentude Ibrahim','Mutaryebwa Luke','Makaayi Hakim','Lucky Dororthy','Nakabugo Haula','Atim Gloria','Mutaka Amos'});
y = [22,23,22,23,22,21,21,21,22,20];
bar(x,y);
xlabel('Names');
ylabel('Ages');
title('A bar graph of Ages against Names');
% step plot of sin(Ages) against Ages
figure ('Name','step plot of sin(Ages) against Ages');
m = [22,23,22,23,22,21,21,21,22,20];
n = sin(m);
stairs(m,n);
xlabel('Ages');
ylabel('sin(Ages)');
grid on;
title('step plot of sin(Ages) against Ages');
%stem plot of cos(Ages) against Ages
figure('Name','stem plot of cos(Ages) against Ages');
p = [22,23,22,23,22,21,21,21,22,20];
q = cos(m);
stem(p,q);
xlabel('Ages');
ylabel('cos(Ages)');
title('stem plot of cos(Ages) against Ages');
grid on;
% A horizontal bar graph of Names against Ages
figure('Name','A horizontal bar graph of Names against Ages');
r = categorical({'Ikeo Jesca','Mugisha Peter','Atusiimirwe Olivia','Ssentude Ibrahim','Mutaryebwa Luke','Makaayi Hakim','Lucky Dororthy','Nakabugo Haula','Atim Gloria','Mutaka Amos'});
s = [22,23,22,23,22,21,21,21,22,20];
barh(r,s);
xlabel('Ages');
ylabel('Names');
grid on;
title('horizontal bar graph of Names against Ages');
% line plot of Ages against Sin(Ages)
figure('Name','line plot of Ages against Sin(Ages)');
a = 20:0.5:23;
b = sin(a);
plot(a,b);
xlabel('Ages');
ylabel('sin(Ages)');
grid on;
title('line plot of Ages against Sin(Ages)');
% scatter plot of Ages against District 
figure('Name','scatter plot of Ages against District');
c = categorical({'Kaberamaido','Ntungamo','Kiruhura','MASAKA','BUSHENYI','WAKISO','Ntungamo','WAKISO','MUKONO','MBALE',});
d = [22,23,22,23,22,21,21,21,22,20];
scatter(c,d);
xlabel('Districts');
ylabel('Ages');
grid on;
title('scatter plot of Ages against District');
% Area plot of Sin Ages against Ages
figure('Name','Area plot of Sin Ages against Ages');
f = 20:0.5:23;
g = sin(f);
area(f,g);
xlabel('Ages');
ylabel('sin(Ages)');
title('Sin Ages against Ages');
grid on;
% Histogram for Ages 
figure('Name','Histogram for Ages');
Ages = [22,23,22,23,22,21,21,21,22,20];
histogram(Ages);
xlabel('Ages');
ylabel('frequency');
title('Histogram of Ages');
grid on;
% Pareto chart for Ages against Names
figure('Name','Pareto chart for Ages against Names');
u =categorical({'Ikeo Jesca','Mugisha Peter','Atusiimirwe Olivia','Ssentude Ibrahim','Mutaryebwa Luke','Makaayi Hakim','Lucky Dororthy','Nakabugo Haula','Atim Gloria','Mutaka Amos'});
v = [22,23,22,23,22,21,21,21,22,20];
pareto(v,u,1);
xlabel('Names');
ylabel('Ages');
grid on;
title('Pareto chart for Ages against Names');
% Box plot of Ages 
figure('Name','Box plot of Ages');
data = randn(23,20);
boxplot(data);
grid on;
title( 'box plot of Ages');
% pie chart of Ages
figure('Name','pie chart of Ages')
h = [22 23 22 23 22 21 21 21 22 20];
pie([1,3,4,2],{'Age20','Age21','Age22','Age23'});
legend('Age20','Age21','Age22','Age23');
title('pie chart of Ages');
% semilogx plot of Ages 
figure('Name','semilogx plot of Ages');
i =linspace(20,10,23);
j = exp(i);
semilogx(i,j);
grid on;
title('semilogx plot');
% 3D surface plot of Ages
figure('Name','3D surface plot of Ages');
w = 20:0.05:23;
[W,O] = meshgrid(w);
z = W.^2 + O.^2;
surf(W,O,z);
xlabel('Ages');
ylabel('Y');
zlabel('Z');
grid on;
legend('Surface Plot');
colorbar('southoutside');
% Mesh plot of Ages
figure('Name','Mesh plot of Ages');
l = 20:0.05:23;
[L,E] = meshgrid(l);
k = sin(L) + cos(E);
mesh(L, E, k);
colorbar;
xlabel('Ages');
ylabel('Y');
zlabel('Z');
grid on;
title('Mesh Plot');
% Waterfall Plot
figure('Name','Waterfall Plot');
s = 20:23;
[S,T] = meshgrid(s);
aa = sin(S) + cos(T);
waterfall(S,T,aa);
xlabel('Ages');
ylabel('Y');
zlabel('Z');
grid on;
title('Waterfall Plot');
% 3D Scatter Plot
figure('Name','3D Scatter Plot');
ab = randn(23,20);
ac = randn(23,20);
ad = randn(23,20);
scatter3(ab, ac, ad);
title('3D Scatter Plot');
xlabel('Ages');
ylabel('Ages');
zlabel('Ages');
%Stem3 Plot
figure('Name','Stem3 Plot');
ae = 20:23;
af = sin(ae);
ag = cos(ae);
stem3(ae, af, ag);
title('3D Stem Plot');
xlabel('Ages');
ylabel('Sin(Ages)');
zlabel('cos(Ages)');
% Quiver3 Plot
figure('Name','Quiver3 Plot');
ah = 20:0.05:23;
[AH,AI,AJ] = meshgrid(ah);
BA = sin(AH);
BB = cos(AI);
BC = AJ;
quiver3(AH,AI,AJ,BA,BB,BC);
title('3D Quiver Plot');
xlabel('Ages');
ylabel('Sin(Ages)');
zlabel('cos(Ages)');
%Contour3 Plot
figure('Name','Contour3 Plot');
ak = 20:0.2:23;
[AK,AL,AM] = peaks(30);
contour3(AK,AL,AM,50);
title('3D Contour Plot');
xlabel('Ages');
ylabel('Ages');
zlabel('Ages');
%Surfc Plot
figure('Name','Surfc Plot');
an = 20:0.2:23;
[AN,AO] = meshgrid(an);
AP = AN.^2 + AO.^2;
surfc(AN,AO,AP);
title('surfc Plot');
xlabel('Ages');
ylabel('Y');
zlabel('Z');
% 3D Bar Plot
figure('Name','3D Bar Plot');
data = randi(23,20);
bar3(data);
title('3D Bar Plot');
xlabel('Ages');
ylabel('Y');
zlabel('Z');
% Ribbon Plot
figure('Name','Ribbon Plot');
aq = 20:23;
ar = magic (4);
ribbon( aq,ar);
title('Ribbon plot showing ages for group one members');
xlabel('Ages');
ylabel('Y');
zlabel('Z');
% Streamslice 3d plot
figure('Name','Streamslice 3d plot');
as = 20:0.1:23;
[AS,AT,AU] = meshgrid(as);
AV = sin(AS);
AW = cos(AT);
AX = AU;
streamslice(AS,AT,AU,AV,AW,AX,[],[],20);
xlabel('Age');
ylabel('Y');
title('Streamslice plot');
% 3d line Plot
figure('Name','3d line Plot');
bd = 20:0.1:23;
be = sin(bd);
bf = cos(bd);
plot3(bd, be, bf);
title('3D line Plot');
xlabel('Ages');
ylabel('Y');
zlabel('Z');
% Compass Plot 
figure('Name','Compass Plot');
bg = randn(23,20);
bh = randn(23,20);
compass(bg,bh);
title('Compass Plot');
grid on;
% Heat map 
figure('Name','Heat map');
bi = randn(23,20);
heatmap(bi);
title('Heatmap');
% Parallel Cordinates Plot
figure('Name','Parallel Cordinates Plot');
bj = randn(23,20);
parallelplot(bj);
title ('Parallel Cordinates Plot');
% Andrews Plot
figure('Name','Andrews Plot');
bk = randn(23,20);
andrewsplot(bk);
title('Andrews Plot');





