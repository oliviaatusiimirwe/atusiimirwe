classdef sublagrange < parentlagrangemethod
    % Based on the Lagrange interpolation a differential numerical method.
    
    methods
        function obj = sublagrange(func, lowerlimit, upperlimit, steps)
            % Constructor calls parent class to initialize shared parameters
            obj@parentlagrangemethod(func, lowerlimit, upperlimit, steps);
        end

        function result = solve(obj)
            % Solves the differential problem using Lagrange method
            % Define sample points
            x = linspace(obj.lowerlimit, obj.upperlimit, obj.steps);
            y = obj.func(x);

            % Construct symbolic variable
            xp = sym('xp');
            sm = 0; % Interpolating polynomial initialization

            % Building the Lagrange polynomial
            for i = 1:obj.steps
                pr = 1;
                for j = 1:obj.steps
                    if j ~= i
                        pr = pr * (xp - x(j)) / (x(i) - x(j));
                    end
                end
                pr = pr * y(i);
                sm = sm + pr; % add current term to total summation
            end

            % Simplify symbolic polynomial
            sm = simplify(sm);

            % Differentiate polynomial symbolically
            dsm = diff(sm, xp);

            % Evaluate derivative at the given x points
            dy = double(subs(dsm, xp, x));

            % Store in result structure
            result.x = x;
            result.y = y;
            result.dsm = dsm;
            result.dy = dy;
            result.sm = sm;
        end

        function displayResult(~, result)
            fprintf('\n=== Differential Problem using Lagrange Method ===\n');
            disp('Interpolating Polynomial (f(x)):');
            disp(result.sm);
            disp('Derivative of Polynomial (df/dx):');
            disp(result.dsm);

            figure('Name','Differential Problem - Lagrange Method');
            hold on;
            plot(result.x, result.y, 'bo-', 'LineWidth', 1.5);
            plot(result.x, result.dy, 'r*-', 'LineWidth', 1.5);
            legend('Original Function','Estimated Derivative','Location','Best');
            xlabel('x');
            ylabel('y and dy/dx');
            title('Numerical Differentiation using Lagrange Interpolation');
            grid on;
            hold off;
        end
    end
end