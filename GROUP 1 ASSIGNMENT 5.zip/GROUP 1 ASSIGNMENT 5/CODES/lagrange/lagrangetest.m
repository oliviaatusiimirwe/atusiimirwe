clc; clear; close all;

% Define the target function directly (no user input)
func = @(x) x.^3 + 2*x.^2 + x;  % A solvable polynomial

% Define parameters for the range and number of points
lowerlimit = 0;
upperlimit = 5;
steps = 6;

% Create an instance of the Lagrange-based Differential Problem
diffProb = DifferentialProblem(func, lowerlimit, upperlimit, steps);

% Solve using Lagrange interpolation differentiation
result = diffProb.solve();

% Display and plot results
diffProb.displayResult(result);