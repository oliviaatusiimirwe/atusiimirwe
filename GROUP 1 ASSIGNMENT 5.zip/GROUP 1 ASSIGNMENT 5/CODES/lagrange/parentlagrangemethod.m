classdef (Abstract) parentlagrangemethod
    % ABSTRACT BASE CLASS for numerical computation problems
    properties (Access = protected)
        func            % Function handle (the mathematical function)
        lowerlimit      % Lower limit (start point)
        upperlimit      % Upper limit (end point)
        steps           % Number of steps/intervals
    end

    methods  % Constructor_method: initialize common parameters
        function obj = parentlagrangemethod(func, lowerlimit, upperlimit, steps)
            obj.func = func;
            obj.lowerlimit = lowerlimit;
            obj.upperlimit = upperlimit;
            obj.steps = steps;
        end
    end

    methods (Abstract)
        result = solve(obj)        % Abstract method for solving the problem
        displayResult(obj, result) % Abstract display method 
    end
end