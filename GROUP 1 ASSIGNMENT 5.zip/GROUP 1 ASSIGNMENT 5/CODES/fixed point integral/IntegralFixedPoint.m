classdef IntegralFixedPoint < NumericalMethod
    properties
        methodName = 'Integral Fixed Point'
        maxIterations
        tolerance
    end
    
    methods
        function obj = IntegralFixedPoint(maxIter, tol)
            obj.maxIterations = maxIter;
            obj.tolerance = tol;
        end
        
        function solution = solve(obj, problem, initialGuess)
            solution = obj.fixed_recursive(initialGuess, obj.tolerance, obj.maxIterations, 0, problem);
        end
        
        function root = fixed_recursive(obj, xO, e, n, iter, g)
            if iter >= n
                root = xO;
                return;
            end

            x1 = g(xO);

            if abs(x1 - xO) < e
                root = x1;
                return;
            end

            root = obj.fixed_recursive(x1, e, n, iter+1, g);
        end
        
        function isValid = validateInput(~, ~)
            isValid = true;
        end
        
        function error = getError(~)
            error = 0;
        end
    end
end