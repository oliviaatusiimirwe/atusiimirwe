fprintf('\n=== Testing Integral Fixed Point ===\n');
int_solver = IntegralFixedPoint(n, e);
solution2 = int_solver.solve(g, x0);
fprintf('Root: %.4f\n', solution2);
