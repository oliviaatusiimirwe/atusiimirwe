classdef NumericalMethod < handle
    properties (Abstract)
        methodName
    end
    
    methods (Abstract)
        solution = solve(obj, problem, varargin)
        isValid = validateInput(obj, problem)
        error = getError(obj)
    end
end