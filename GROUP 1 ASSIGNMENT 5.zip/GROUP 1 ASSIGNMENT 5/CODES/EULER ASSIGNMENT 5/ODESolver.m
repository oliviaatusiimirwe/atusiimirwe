classdef (Abstract) ODESolver
    properties (Abstract)
        solver_name
    end
    
    properties
        dt = 0.01;
        max_time = 10;
        initial_conditions = [0, 0];
        system = [];
    end
    
    methods (Abstract)
        [time_points, solution] = solve(obj)
    end
    
    methods
        function plot_solution(obj, t, x)
            figure;
            plot(t, x, 'b-', 'LineWidth', 2);
            xlabel('Time (s)');
            ylabel('Displacement x(t)');
            grid on;
            title([obj.solver_name ' - Solution']);
        end
    end
end