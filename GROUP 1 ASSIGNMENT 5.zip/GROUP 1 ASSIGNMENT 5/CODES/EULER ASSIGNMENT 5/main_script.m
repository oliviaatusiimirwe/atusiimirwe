% Testing the ODE solver 
fprintf('ODE Solver Simulation Started...\n');

% Create different systems and solvers to demonstrate polymorphism
oscillator1 = DampedDrivenOscillator(3, 2, 2, 5);
oscillator2 = DampedDrivenOscillator(5, 1, 1, 3);

fprintf('Testing completed successfully!\n');