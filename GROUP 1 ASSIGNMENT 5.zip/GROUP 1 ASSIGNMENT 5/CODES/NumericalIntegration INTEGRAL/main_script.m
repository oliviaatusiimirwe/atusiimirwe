clc; clear; close all;
fprintf('--- NUMERICAL INTEGRATION USING OOP (Water Tank Example) ---\n\n');

% Define the water height profile
f = @(x) 10 * sin(pi * x / 10);

% Limits and subintervals
a = 0; b = 10; n = 20;

% Create integration objects
trap = TrapezoidalIntegration(a, b, n);
simp = SimpsonsIntegration(a, b, n);

% Compute
A_trap = trap.integrate(f);
A_simp = simp.integrate(f);

% Exact analytical value
A_exact = (100/pi) * (1 - cos(pi * b / 10));

% Display
fprintf('Estimated cross-sectional area of water in tank:\n');
fprintf('------------------------------------------------\n');
fprintf('Trapezoidal Rule: %.5f m^2\n', A_trap);
fprintf('Simpson 1/3 Rule: %.5f m^2\n', A_simp);
fprintf('Exact Analytical Value: %.5f m^2\n\n', A_exact);

% Plot
x = linspace(a, b, 200);
plot(x, f(x), 'b-', 'LineWidth', 1.5);
xlabel('x (m)');
ylabel('h(x) (m)');
title('Water Height Profile: h(x) = 10 sin(\pi x / 10)');
grid on;
