% Test the fixed point iteration implementation

fprintf('=== Testing Differential Fixed Point Iteration ===\n');

% Test case 1: Solve x = cos(x)
g1 = @(x) cos(x);
diff_solver = DifferentialFixedPoint(10, 1e-6);  % Use positional arguments
solution1 = diff_solver.solve(g1, 0.5);
fprintf('Solution for x = cos(x): %.8f\n', solution1);
