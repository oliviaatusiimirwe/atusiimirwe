classdef NumericalMethod < handle
    % NUMERICALMETHOD Abstract base class for numerical methods
    % This class defines the interface for all numerical methods
    
    properties (Abstract)
        methodName
    end
    
    methods (Abstract)
        % Solve the numerical problem
        solution = solve(obj, problem, varargin)
        
        % Validate input parameters
        isValid = validateInput(obj, problem)
        
        % Get error estimate
        error = getError(obj)
    end
    
    methods
        function displayInfo(obj)
            fprintf('Numerical Method: %s\n', obj.methodName);
        end
    end
end
